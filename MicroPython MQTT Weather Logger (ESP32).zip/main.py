"""
Termômetro de Aviário com ESP32, DHT22 e MQTT (HiveMQ)
- Aciona LED se a temperatura estiver fora da faixa ideal
- Publica dados no broker MQTT (HiveMQ)
"""

import network
import time
from machine import Pin
import dht
import ujson
from umqtt.simple import MQTTClient

# Configurações MQTT HiveMQ
MQTT_CLIENT_ID = "aviario-esp32"
MQTT_BROKER = "broker.hivemq.com"
MQTT_PORT = 1883
MQTT_USER = ""
MQTT_PASSWORD = ""
MQTT_TOPIC = "aviario/teste"

# Faixa ideal de temperatura
TEMP_MIN = 21
TEMP_MAX = 26

# Inicialização de sensores e atuadores
sensor = dht.DHT22(Pin(15))  
ventilador = Pin(23, Pin.OUT)       # LED pro aquecedor
aquecedor = Pin(19, Pin.OUT)

# Conexão Wi-Fi
print("Conectando ao WiFi", end="")
sta_if = network.WLAN(network.STA_IF)
sta_if.active(True)
sta_if.connect('Wokwi-GUEST', '')
while not sta_if.isconnected():
    print(".", end="")
    time.sleep(0.1)
print(" Conectado!")

# Conexão MQTT
print("Conectando ao broker HiveMQ... ", end="")
client = MQTTClient(client_id=MQTT_CLIENT_ID, server=MQTT_BROKER, port=MQTT_PORT)
client.connect()
print("Conectado!")

# Loop principal
while True:
    sensor.measure()
    temp = sensor.temperature()
    humidity = sensor.humidity()

    if temp < TEMP_MIN:
        status = "Temperatura baixa - ligando aquecedor"
        aquecedor.on()
        ventilador.off()
    elif temp > TEMP_MAX:
        status = "Temperatura alta - ligando ventilador"
        ventilador.on()
        aquecedor.off()
    else:
        status = "Temperatura ideal"
        ventilador.off()
        aquecedor.off()

    print("Temperatura: {:.1f}°C | Umidade: {:.1f}% | {}".format(temp, humidity, status))

    message = ujson.dumps({
        "temperatura": temp,
        "umidade": humidity,
        "status": status
    })

    try:
        client.publish(MQTT_TOPIC, message)
        print("Publicado com sucesso:", message)
    except Exception as e:
        print("Erro ao publicar no MQTT:", e)

    time.sleep(5)
